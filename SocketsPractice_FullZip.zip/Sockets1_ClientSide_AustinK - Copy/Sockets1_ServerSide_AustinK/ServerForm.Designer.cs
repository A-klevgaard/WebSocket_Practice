﻿
namespace Sockets1_ServerSide_AustinK
{
    partial class ServerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.numClientsLabel = new System.Windows.Forms.Label();
            this.maxClientsLabel = new System.Windows.Forms.Label();
            this.listenerStatus = new System.Windows.Forms.Label();
            this.currentClientCountText = new System.Windows.Forms.TextBox();
            this.listenerStatusDisplay = new System.Windows.Forms.Label();
            this.maxClientsUD = new System.Windows.Forms.NumericUpDown();
            this.listenerPollTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.maxClientsUD)).BeginInit();
            this.SuspendLayout();
            // 
            // numClientsLabel
            // 
            this.numClientsLabel.AutoSize = true;
            this.numClientsLabel.Location = new System.Drawing.Point(12, 26);
            this.numClientsLabel.Name = "numClientsLabel";
            this.numClientsLabel.Size = new System.Drawing.Size(118, 17);
            this.numClientsLabel.TabIndex = 0;
            this.numClientsLabel.Text = "Number of clients";
            // 
            // maxClientsLabel
            // 
            this.maxClientsLabel.AutoSize = true;
            this.maxClientsLabel.Location = new System.Drawing.Point(12, 76);
            this.maxClientsLabel.Name = "maxClientsLabel";
            this.maxClientsLabel.Size = new System.Drawing.Size(87, 17);
            this.maxClientsLabel.TabIndex = 1;
            this.maxClientsLabel.Text = "Max Clients: ";
            // 
            // listenerStatus
            // 
            this.listenerStatus.AutoSize = true;
            this.listenerStatus.Location = new System.Drawing.Point(12, 119);
            this.listenerStatus.Name = "listenerStatus";
            this.listenerStatus.Size = new System.Drawing.Size(111, 17);
            this.listenerStatus.TabIndex = 2;
            this.listenerStatus.Text = "Listener Status: ";
            // 
            // currentClientCountText
            // 
            this.currentClientCountText.Location = new System.Drawing.Point(136, 26);
            this.currentClientCountText.Name = "currentClientCountText";
            this.currentClientCountText.ReadOnly = true;
            this.currentClientCountText.Size = new System.Drawing.Size(100, 22);
            this.currentClientCountText.TabIndex = 3;
            this.currentClientCountText.Text = "0";
            // 
            // listenerStatusDisplay
            // 
            this.listenerStatusDisplay.AutoSize = true;
            this.listenerStatusDisplay.Location = new System.Drawing.Point(133, 119);
            this.listenerStatusDisplay.Name = "listenerStatusDisplay";
            this.listenerStatusDisplay.Size = new System.Drawing.Size(27, 17);
            this.listenerStatusDisplay.TabIndex = 5;
            this.listenerStatusDisplay.Text = "On";
            // 
            // maxClientsUD
            // 
            this.maxClientsUD.Location = new System.Drawing.Point(136, 76);
            this.maxClientsUD.Name = "maxClientsUD";
            this.maxClientsUD.Size = new System.Drawing.Size(120, 22);
            this.maxClientsUD.TabIndex = 6;
            this.maxClientsUD.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // listenerPollTimer
            // 
            this.listenerPollTimer.Enabled = true;
            this.listenerPollTimer.Tick += new System.EventHandler(this.listenerPollTimer_Tick);
            // 
            // ServerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 167);
            this.Controls.Add(this.maxClientsUD);
            this.Controls.Add(this.listenerStatusDisplay);
            this.Controls.Add(this.currentClientCountText);
            this.Controls.Add(this.listenerStatus);
            this.Controls.Add(this.maxClientsLabel);
            this.Controls.Add(this.numClientsLabel);
            this.Name = "ServerForm";
            this.Text = "NumGuess Server";
            this.Load += new System.EventHandler(this.ServerForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.maxClientsUD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label numClientsLabel;
        private System.Windows.Forms.Label maxClientsLabel;
        private System.Windows.Forms.Label listenerStatus;
        private System.Windows.Forms.TextBox currentClientCountText;
        private System.Windows.Forms.Label listenerStatusDisplay;
        private System.Windows.Forms.NumericUpDown maxClientsUD;
        private System.Windows.Forms.Timer listenerPollTimer;
    }
}

