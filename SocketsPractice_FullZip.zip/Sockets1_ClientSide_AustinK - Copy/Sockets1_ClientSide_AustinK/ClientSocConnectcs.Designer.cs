﻿
namespace Sockets1_ClientSide_AustinK
{
    partial class ClientSocConnect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addressLabel = new System.Windows.Forms.Label();
            this.portLabel = new System.Windows.Forms.Label();
            this.addressInput = new System.Windows.Forms.TextBox();
            this.portInput = new System.Windows.Forms.TextBox();
            this.connectButton = new System.Windows.Forms.Button();
            this.connectionGoodLabel = new System.Windows.Forms.Label();
            this.connectIndicator = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(12, 31);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(64, 17);
            this.addressLabel.TabIndex = 0;
            this.addressLabel.Text = "Address:";
            // 
            // portLabel
            // 
            this.portLabel.AutoSize = true;
            this.portLabel.Location = new System.Drawing.Point(12, 79);
            this.portLabel.Name = "portLabel";
            this.portLabel.Size = new System.Drawing.Size(42, 17);
            this.portLabel.TabIndex = 1;
            this.portLabel.Text = "Port: ";
            // 
            // addressInput
            // 
            this.addressInput.Location = new System.Drawing.Point(85, 31);
            this.addressInput.Name = "addressInput";
            this.addressInput.Size = new System.Drawing.Size(144, 22);
            this.addressInput.TabIndex = 2;
            this.addressInput.Text = "bits.net.nait.ca";
            // 
            // portInput
            // 
            this.portInput.Location = new System.Drawing.Point(85, 79);
            this.portInput.Name = "portInput";
            this.portInput.ReadOnly = true;
            this.portInput.Size = new System.Drawing.Size(144, 22);
            this.portInput.TabIndex = 3;
            this.portInput.Text = "1666";
            // 
            // connectButton
            // 
            this.connectButton.Location = new System.Drawing.Point(85, 116);
            this.connectButton.Name = "connectButton";
            this.connectButton.Size = new System.Drawing.Size(106, 29);
            this.connectButton.TabIndex = 4;
            this.connectButton.Text = "Connect";
            this.connectButton.UseVisualStyleBackColor = true;
            this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
            // 
            // connectionGoodLabel
            // 
            this.connectionGoodLabel.AutoSize = true;
            this.connectionGoodLabel.Location = new System.Drawing.Point(8, 180);
            this.connectionGoodLabel.Name = "connectionGoodLabel";
            this.connectionGoodLabel.Size = new System.Drawing.Size(87, 17);
            this.connectionGoodLabel.TabIndex = 5;
            this.connectionGoodLabel.Text = "Connection: ";
            // 
            // connectIndicator
            // 
            this.connectIndicator.AutoSize = true;
            this.connectIndicator.BackColor = System.Drawing.Color.Red;
            this.connectIndicator.Location = new System.Drawing.Point(98, 180);
            this.connectIndicator.Name = "connectIndicator";
            this.connectIndicator.Size = new System.Drawing.Size(42, 17);
            this.connectIndicator.TabIndex = 6;
            this.connectIndicator.Text = "None";
            // 
            // ClientSocConnect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(253, 207);
            this.Controls.Add(this.connectIndicator);
            this.Controls.Add(this.connectionGoodLabel);
            this.Controls.Add(this.connectButton);
            this.Controls.Add(this.portInput);
            this.Controls.Add(this.addressInput);
            this.Controls.Add(this.portLabel);
            this.Controls.Add(this.addressLabel);
            this.Name = "ClientSocConnect";
            this.Text = "Client Connect";
            this.Load += new System.EventHandler(this.ClientSocConnect_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label portLabel;
        private System.Windows.Forms.TextBox addressInput;
        private System.Windows.Forms.TextBox portInput;
        private System.Windows.Forms.Button connectButton;
        private System.Windows.Forms.Label connectionGoodLabel;
        private System.Windows.Forms.Label connectIndicator;
    }
}