﻿
namespace Sockets1_ClientSide_AustinK
{
    partial class NumGuessSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sendGuessButton = new System.Windows.Forms.Button();
            this.guessTrackbar = new System.Windows.Forms.TrackBar();
            this.lowLabel = new System.Windows.Forms.Label();
            this.guessLabel = new System.Windows.Forms.Label();
            this.highLabel = new System.Windows.Forms.Label();
            this.statusLabel = new System.Windows.Forms.Label();
            this.connectButton = new System.Windows.Forms.Button();
            this.guessDisplay = new System.Windows.Forms.Label();
            this.lowDisplay = new System.Windows.Forms.Label();
            this.highDisplay = new System.Windows.Forms.Label();
            this.connectStatusLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.guessTrackbar)).BeginInit();
            this.SuspendLayout();
            // 
            // sendGuessButton
            // 
            this.sendGuessButton.Location = new System.Drawing.Point(328, 201);
            this.sendGuessButton.Name = "sendGuessButton";
            this.sendGuessButton.Size = new System.Drawing.Size(125, 54);
            this.sendGuessButton.TabIndex = 0;
            this.sendGuessButton.Text = "Send Guess";
            this.sendGuessButton.UseVisualStyleBackColor = true;
            this.sendGuessButton.Click += new System.EventHandler(this.sendGuessButton_Click);
            // 
            // guessTrackbar
            // 
            this.guessTrackbar.Location = new System.Drawing.Point(12, 109);
            this.guessTrackbar.Maximum = 1000;
            this.guessTrackbar.Minimum = 1;
            this.guessTrackbar.Name = "guessTrackbar";
            this.guessTrackbar.Size = new System.Drawing.Size(776, 56);
            this.guessTrackbar.TabIndex = 1;
            this.guessTrackbar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.guessTrackbar.Value = 500;
            this.guessTrackbar.Scroll += new System.EventHandler(this.guessTrackbar_Scroll);
            // 
            // lowLabel
            // 
            this.lowLabel.AutoSize = true;
            this.lowLabel.Location = new System.Drawing.Point(22, 137);
            this.lowLabel.Name = "lowLabel";
            this.lowLabel.Size = new System.Drawing.Size(41, 17);
            this.lowLabel.TabIndex = 2;
            this.lowLabel.Text = "Low: ";
            // 
            // guessLabel
            // 
            this.guessLabel.AutoSize = true;
            this.guessLabel.Location = new System.Drawing.Point(325, 168);
            this.guessLabel.Name = "guessLabel";
            this.guessLabel.Size = new System.Drawing.Size(57, 17);
            this.guessLabel.TabIndex = 3;
            this.guessLabel.Text = "Guess: ";
            // 
            // highLabel
            // 
            this.highLabel.AutoSize = true;
            this.highLabel.Location = new System.Drawing.Point(703, 137);
            this.highLabel.Name = "highLabel";
            this.highLabel.Size = new System.Drawing.Size(45, 17);
            this.highLabel.TabIndex = 4;
            this.highLabel.Text = "High: ";
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(234, 57);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(91, 29);
            this.statusLabel.TabIndex = 6;
            this.statusLabel.Text = "Status: ";
            // 
            // connectButton
            // 
            this.connectButton.Location = new System.Drawing.Point(12, 12);
            this.connectButton.Name = "connectButton";
            this.connectButton.Size = new System.Drawing.Size(121, 63);
            this.connectButton.TabIndex = 7;
            this.connectButton.Text = "Connect to Play";
            this.connectButton.UseVisualStyleBackColor = true;
            this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
            // 
            // guessDisplay
            // 
            this.guessDisplay.AutoSize = true;
            this.guessDisplay.Location = new System.Drawing.Point(378, 168);
            this.guessDisplay.Name = "guessDisplay";
            this.guessDisplay.Size = new System.Drawing.Size(46, 17);
            this.guessDisplay.TabIndex = 8;
            this.guessDisplay.Text = "guess";
            // 
            // lowDisplay
            // 
            this.lowDisplay.AutoSize = true;
            this.lowDisplay.Location = new System.Drawing.Point(63, 137);
            this.lowDisplay.Name = "lowDisplay";
            this.lowDisplay.Size = new System.Drawing.Size(28, 17);
            this.lowDisplay.TabIndex = 9;
            this.lowDisplay.Text = "low";
            // 
            // highDisplay
            // 
            this.highDisplay.AutoSize = true;
            this.highDisplay.Location = new System.Drawing.Point(744, 137);
            this.highDisplay.Name = "highDisplay";
            this.highDisplay.Size = new System.Drawing.Size(35, 17);
            this.highDisplay.TabIndex = 10;
            this.highDisplay.Text = "high";
            // 
            // connectStatusLabel
            // 
            this.connectStatusLabel.AutoSize = true;
            this.connectStatusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.connectStatusLabel.Location = new System.Drawing.Point(9, 261);
            this.connectStatusLabel.Name = "connectStatusLabel";
            this.connectStatusLabel.Size = new System.Drawing.Size(108, 18);
            this.connectStatusLabel.TabIndex = 11;
            this.connectStatusLabel.Text = "Not Connected";
            // 
            // NumGuessSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 288);
            this.Controls.Add(this.connectStatusLabel);
            this.Controls.Add(this.highDisplay);
            this.Controls.Add(this.lowDisplay);
            this.Controls.Add(this.guessDisplay);
            this.Controls.Add(this.connectButton);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.highLabel);
            this.Controls.Add(this.guessLabel);
            this.Controls.Add(this.lowLabel);
            this.Controls.Add(this.guessTrackbar);
            this.Controls.Add(this.sendGuessButton);
            this.Name = "NumGuessSelector";
            this.Text = "Number Guesser";
            this.Load += new System.EventHandler(this.NumGuessSelector_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guessTrackbar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sendGuessButton;
        private System.Windows.Forms.TrackBar guessTrackbar;
        private System.Windows.Forms.Label lowLabel;
        private System.Windows.Forms.Label guessLabel;
        private System.Windows.Forms.Label highLabel;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Button connectButton;
        private System.Windows.Forms.Label guessDisplay;
        private System.Windows.Forms.Label lowDisplay;
        private System.Windows.Forms.Label highDisplay;
        private System.Windows.Forms.Label connectStatusLabel;
    }
}

